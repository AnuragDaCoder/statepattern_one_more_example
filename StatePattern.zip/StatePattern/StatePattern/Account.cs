﻿namespace StatePattern
{
    public class SavingsBankAccount
    {
        private IState State { get; set; }

        private double BalanceInSavingAccount { get; set; }    

        public SavingsBankAccount()
        {
            State = new BasicCardElligibility();
        }

        public void Deposit(double amount)
        {
            BalanceInSavingAccount += amount;
            CheckCreditCardElligibility();
        }

        public void Withdraw(double amount)
        {
            BalanceInSavingAccount -= amount;
            CheckCreditCardElligibility();
        }

        public void CheckCurrentCreditCardBenefits()
        {
            State.Facilities();
        }
        public void CheckCreditCardElligibility()
        {
            if(BalanceInSavingAccount <= 5000)
                State = new BasicCardElligibility();
            if (BalanceInSavingAccount > 50000 && BalanceInSavingAccount < 100000)
                State = new SignatureCardElligibility();
            if (BalanceInSavingAccount >= 100000)
                State = new TitaniumCreditCardElligibility();
        }
    }

}
