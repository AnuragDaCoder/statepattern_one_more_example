﻿using StatePattern;

SavingsBankAccount savingsBankAccount = new();
savingsBankAccount.Deposit(1000);
savingsBankAccount.CheckCurrentCreditCardBenefits();

Console.WriteLine("---------------------");
savingsBankAccount.Deposit(50000);
savingsBankAccount.CheckCurrentCreditCardBenefits();
Console.WriteLine("---------------------");
savingsBankAccount.Deposit(60000);
savingsBankAccount.CheckCurrentCreditCardBenefits();
Console.WriteLine("---------------------");
savingsBankAccount.Withdraw(20000);
savingsBankAccount.CheckCurrentCreditCardBenefits();