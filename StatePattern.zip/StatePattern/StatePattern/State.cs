﻿
namespace StatePattern
{
    public interface IState
    {
        void Facilities();
    }

    public class BasicCardElligibility : IState
    {
        public void Facilities()
        {
            Console.WriteLine("Basic Card");
            Console.WriteLine("1 movie ticket free in 6 month");
        }
    }

    public class SignatureCardElligibility : IState
    {
        public void Facilities()
        {
            Console.WriteLine("Signature Card");
            Console.WriteLine("2 movie ticket free in 1 month");
        }
    }

    public class TitaniumCreditCardElligibility : IState
    {
        public void Facilities()
        {
            Console.WriteLine("Titaninum Card");
            Console.WriteLine("5 movie ticket free in 1 month");
        }
    }

}
